﻿using DAL.Persistence;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using DAL.Model;

namespace TestDAL
{
    
    
    /// <summary>
    ///This is a test class for ClienteDalTest and is intended
    ///to contain all ClienteDalTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ClienteDalTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for ObterPorCpf
        ///</summary>
        [TestMethod()]
        public void PesquisarClienteTest()
        {
            try
            {
                //Dados de Entrada
                Cliente entrada = new Cliente();
                entrada.Nome  = "Sergio Mendes";
                entrada.Email = "sergio.coti@gmail.com";
                entrada.Cpf   = "0123456789";
                
                //Passos:
                ClienteDal d = new ClienteDal();
                d.Salvar(entrada); //Salvar o Cliente
                Cliente saida = d.ObterPorCpf(entrada.Cpf);

                //Verificar o resultado obtido
                Assert.AreEqual(entrada.Nome, saida.Nome);
                Assert.AreEqual(entrada.Email, saida.Email);
                Assert.AreEqual(entrada.Cpf, saida.Cpf);
            }
            catch(Exception e)
            {
                //Registrar Falha no Teste
                Assert.Fail("Falha no Teste de Pesquisa de Cliente: " + e.Message);
            }
        }
    }
}
