﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using DAL.Model;

namespace DAL.Persistence
{
    public class ClienteDal : Conexao
    {
        //Método para salvar um cliente na tabela
        public void Salvar(Cliente c)
        {
            try
            {
                AbrirConexao();

                Tr = Con.BeginTransaction(); //iniciando uma transação
                
                Cmd = new SqlCommand("insert into Cliente(Nome, Email, Cpf) values(@v1, @v2, @v3)", Con, Tr);
                Cmd.Parameters.AddWithValue("@v1", c.Nome);
                Cmd.Parameters.AddWithValue("@v2", c.Email);
                Cmd.Parameters.AddWithValue("@v3", c.Cpf);
                Cmd.ExecuteNonQuery(); //escreve o comando Sql na base

                Tr.Commit(); //executar a transação
            }
            catch(Exception e)
            {
                Tr.Rollback(); //desfaz a transação
                throw new Exception("Erro ao salvar cliente: " + e.Message);
            }
            finally
            {
                FecharConexao();
            }
        }

        //Método para obter 1 Cliente pelo CPF
        public Cliente ObterPorCpf(string cpf)
        {
            try
            {
                AbrirConexao();

                Cmd = new SqlCommand("select * from Cliente where Cpf = @v1", Con);
                Cmd.Parameters.AddWithValue("@v1", cpf);
                Dr = Cmd.ExecuteReader(); //executa a consulta e lê os registros 

                if(Dr.Read())
                {
                    Cliente c = new Cliente();

                    c.IdCliente = Convert.ToInt32(Dr["IdCliente"]);
                    c.Nome      = Convert.ToString(Dr["Nome"]);
                    c.Email     = Convert.ToString(Dr["Email"]);
                    c.Cpf       = Convert.ToString(Dr["Cpf"]);

                    return c; //retornar o cliente
                }

                return null; //retornar vazio
            }
            catch(Exception e)
            {
                throw new Exception("Erro ao obter cliente: " + e.Message);
            }
            finally
            {
                FecharConexao();
            }
        }


    }
}
