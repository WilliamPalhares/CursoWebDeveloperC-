﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient; //acesso ao sqlserver

namespace DAL.Persistence
{
    public class Conexao
    {
        //Atributos
        protected SqlConnection Con;    //Conexão com o SqlServer
        protected SqlCommand Cmd;       //Executar comandos SQL
        protected SqlDataReader Dr;     //Ler registros de consultas
        protected SqlTransaction Tr;    //Commit / Rollback (transações)

        protected void AbrirConexao()
        {
            Con = new SqlConnection(@"Data Source=PROFESSOR\SQLEXPRESS;Integrated Security=True");
            Con.Open();
        }

        protected void FecharConexao()
        {
            Con.Close();
        }
    }
}
