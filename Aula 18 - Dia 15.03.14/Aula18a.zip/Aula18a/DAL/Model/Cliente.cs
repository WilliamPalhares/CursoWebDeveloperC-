﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL.Model
{
    public class Cliente
    {
        //Atributos
        private int idCliente;
        private string nome;
        private string email;
        private string cpf;

        //Construtor padrão [ctor] + 2x[tab]
        public Cliente()
        {
            //Default
        }

        //Sobrecarga de Métodos (Overloading)
        public Cliente(int idCliente, string nome, string email, string cpf)
        {
            this.idCliente = idCliente;
            this.nome = nome;
            this.email = email;
            this.cpf = cpf;
        }

        public int IdCliente
        {
            set { idCliente = value; }
            get { return idCliente; }
        }

        public string Nome
        {
            set { nome = value; }
            get { return nome; }
        }

        public string Email
        {
            set { email = value; }
            get { return email; }
        }

        public string Cpf
        {
            set { cpf = value; }
            get { return cpf; }
        }
    }
}
