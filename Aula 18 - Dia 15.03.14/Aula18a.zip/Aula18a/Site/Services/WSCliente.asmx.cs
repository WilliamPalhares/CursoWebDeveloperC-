﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using DAL.Model;
using DAL.Persistence;

namespace Site.Services
{
    /// <summary>
    /// Summary description for WSCliente
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WSCliente : System.Web.Services.WebService
    {
        [WebMethod]
        public string PesquisarCliente(string Cpf)
        {
            try
            {
                ClienteDal d = new ClienteDal();
                Cliente c = d.ObterPorCpf(Cpf); //busca 

                if (c != null)
                {
                    return string.Format("{0};{1};{2};{3}", c.IdCliente, c.Nome, c.Email, c.Cpf);
                }
                else //não foi encontrado!
                {
                    return "NOT_FOUND";
                }
            }
            catch
            {
                return "ERROR";
            }
        }
    }
}
