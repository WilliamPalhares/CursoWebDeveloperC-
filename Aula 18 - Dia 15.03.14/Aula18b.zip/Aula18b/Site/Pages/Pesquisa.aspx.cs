﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Site.Service;

namespace Site.Pages
{
    public partial class Pesquisa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnPesquisa_Click(object sender, EventArgs e)
        {
            try
            {
                WSClienteSoapClient ws = new WSClienteSoapClient();
                string resultado = ws.PesquisarCliente(txtCpf.Text);

                if(resultado.Equals("ERROR"))
                {
                    lblMensagem.Text = "Erro ao obter cliente.";
                }
                else if (resultado.Equals("NOT_FOUND"))
                {
                    lblMensagem.Text = "Cliente não encontrado.";
                }
                else
                {
                    lblMensagem.Text = "Cliente: " + resultado;
                }
            }
            catch(Exception ex)
            {
                lblMensagem.Text = ex.Message;
            }
        }
    }
}