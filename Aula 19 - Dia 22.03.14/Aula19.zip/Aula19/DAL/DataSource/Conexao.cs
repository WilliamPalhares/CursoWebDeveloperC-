﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Configuration;
using DAL.Entity;

namespace DAL.DataSource
{
    public class Conexao : DbContext //DbContext -> Classe do EF para acesso ao BD
    {
        //Construtor default (vazio)
        public Conexao()
            : base(ConfigurationManager.ConnectionStrings["aula"].ConnectionString)
        {
            //Passando o caminho da connectionstring
        }

        //Agregar a Classe de entidade -> Produto
        public DbSet<Produto> Produto { get; set; }
        
    }
}
