﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Generics
{
    public interface IGenericDal<T, K> //T e K são genericos
        where T : class   //T é um generico de Classe
        where K : struct  //K é um generico de Estrutura (Tipo)

    {
        void Inserir(T entidade);
        void Excluir(T entidade);
        void Salvar();

        List<T> ListarTodos();
        T ObterPorId(K Id);
    }

}
