﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.DataSource; //conexão

namespace DAL.Generics
{
    //Classe abstrata -> não pode ser instanciada, apenas herdada
    public abstract class GenericDalEntity<T, K> : IGenericDal<T, K>, IDisposable
        where T : class
        where K : struct
    {

        //Atributo para a classe de conexão
        protected Conexao Con; //null

        public GenericDalEntity() //Construtor [ctor] + 2x[tab]
        {
            Con = new Conexao(); //inicializo o atributo de conexão
        }

        public void Inserir(T entidade)
        {
            try
            {
                Con.Set<T>().Add(entidade);                
            }
            catch
            {
                throw;
            }
        }

        public void Excluir(T entidade)
        {
            try
            {
                Con.Set<T>().Remove(entidade);
            }
            catch
            {
                throw;
            }
        }

        public void Salvar()
        {
            Con.SaveChanges();
        }

        public List<T> ListarTodos()
        {
            try
            {
                return Con.Set<T>().ToList();
            }
            catch
            {
                throw;
            }
        }

        public T ObterPorId(K Id)
        {
            try
            {
                return Con.Set<T>().Find(Id);
            }
            catch
            {
                throw;
            }
        }

        public void Dispose()
        {
            Con.Dispose(); //destruir a conexão
        }
    }
}
