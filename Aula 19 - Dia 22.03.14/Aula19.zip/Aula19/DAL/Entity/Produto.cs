﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations; //Mapeamento

namespace DAL.Entity
{
    [Table("Produto")]
    public class Produto
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column]
        public int IdProduto { get; set; }

        [Column]
        public string Nome { get; set; }

        [Column]
        public decimal Preco { get; set; }

        [Column]
        public int Quantidade { get; set; }
    }
}
