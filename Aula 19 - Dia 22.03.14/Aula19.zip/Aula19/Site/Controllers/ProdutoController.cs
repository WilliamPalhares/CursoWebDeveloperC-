﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Http;
using DAL.Entity;
using DAL.Persistence;

namespace Site.Controllers
{
    //API -> Classe para geração de conteudo para outros projetos
    public class ProdutoController : ApiController
    {
        //Método para retornar os produtos que serão acessados por URL
        public List<Produto> GetProdutos() //Nome padrão
        {
            try
            {
                using(ProdutoDal d = new ProdutoDal())
                {
                    return d.ListarTodos(); //retornar uma lista de produtos do banco
                }
            }
            catch
            {
                throw;
            }
        }
    }
}
