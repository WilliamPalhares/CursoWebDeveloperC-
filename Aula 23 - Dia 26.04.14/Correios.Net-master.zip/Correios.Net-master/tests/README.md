Na imagem abaixo você pode ver último teste rodado. Todos testes passaram.

![a](http://s23.postimg.org/co9mbz59n/Tests_Run.png)
