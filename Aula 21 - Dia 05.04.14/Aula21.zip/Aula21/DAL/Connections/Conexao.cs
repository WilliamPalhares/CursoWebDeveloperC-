﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NHibernate;
using NHibernate.Cfg;

namespace DAL.Connections
{
    //static -> já garante que a classe estará alocada em memória
    public static class Conexao
    {
        //Método para gerar a fábrica de conexões do Hibernate
        public static ISessionFactory GetSessionFactory()
        {
            try
            {
                Configuration cfg = new Configuration();
                cfg.Configure(); //lê o arquivo 'hibernate.cfg.xml'
                cfg.AddAssembly("DAL"); //ler todos os arquivos .hbm.xml contidos no projeto DAL

                //Gerar a fábrica de conexões...
                return cfg.BuildSessionFactory();
            }
            catch(Exception e)
            {
                throw new Exception("Erro ao gerar fábrica de conexões: " + e.Message);
            }
        }

    }
}
