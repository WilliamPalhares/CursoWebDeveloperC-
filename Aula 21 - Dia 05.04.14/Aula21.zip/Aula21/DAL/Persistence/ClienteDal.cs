﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NHibernate;
using DAL.Connections;
using DAL.Model;

namespace DAL.Persistence
{
    public class ClienteDal
    {
        //Atributos
        private ISession session;           //SqlConnection Con 
        private ITransaction transaction;   //SqlCommand Cmd
        private IQuery query;               //SqlDataReader Dr

        //Método para gravar Cliente na base
        public void Salvar(Cliente c)
        {
            try
            {
                session = Conexao.GetSessionFactory().OpenSession(); //conexão aberta
                transaction = session.BeginTransaction(); //iniciando uma transação
                session.Save(c); //insert
                transaction.Commit(); //executar
            }
            catch(Exception e)
            {
                transaction.Rollback(); //desfazer
                throw new Exception("Erro ao salvar cliente: " + e.Message);
            }
            finally
            {
                session.Close(); //fechar a conexão
            }
        }

        //Método para excluir Cliente na base
        public void Excluir(Cliente c)
        {
            try
            {
                session = Conexao.GetSessionFactory().OpenSession(); //conexão aberta
                transaction = session.BeginTransaction(); //iniciando uma transação
                session.Delete(c); //delete
                transaction.Commit(); //executar
            }
            catch (Exception e)
            {
                transaction.Rollback(); //desfazer
                throw new Exception("Erro ao excluir cliente: " + e.Message);
            }
            finally
            {
                session.Close(); //fechar a conexão
            }
        }

        //Método para atualizar Cliente na base
        public void Atualizar(Cliente c)
        {
            try
            {
                session = Conexao.GetSessionFactory().OpenSession(); //conexão aberta
                transaction = session.BeginTransaction(); //iniciando uma transação
                session.Update(c); //update
                transaction.Commit(); //executar
            }
            catch (Exception e)
            {
                transaction.Rollback(); //desfazer
                throw new Exception("Erro ao atualizar cliente: " + e.Message);
            }
            finally
            {
                session.Close(); //fechar a conexão
            }
        }

        //Método para obter 1 Cliente pelo Id
        public Cliente ObterPorId(int IdCliente)
        {
            try
            {
                session = Conexao.GetSessionFactory().OpenSession(); //conexão aberta
                //SQL => select * from Cliente where IdCliente = @v1
                return session.Get(typeof(Cliente), IdCliente) as Cliente;
            }
            catch(Exception e)
            {
                throw new Exception("Erro ao obter cliente por id: " + e.Message);
            }
            finally
            {
                session.Close();
            }
        }

        //Método para listar todos os clientes cadastrados na base
        public List<Cliente> ListarTodos()
        {
            try
            {
                session = Conexao.GetSessionFactory().OpenSession(); //abrir conexão
                //SQL => select * from Cliente order by DataCadastro desc
                query = session.CreateQuery("select c from Cliente as c order by c.DataCadastro desc"); //HQL
                //executar e obter o resultado da consulta
                var dados = query.List(); //IList
                
                //retornar os dados obtidos como List<Cliente>
                return dados.OfType<Cliente>().ToList();
            }
            catch(Exception e)
            {
                throw new Exception("Erro ao listar todos: " + e.Message);
            }
            finally
            {
                session.Close(); //fechar conexão
            }
        }

    }
}
