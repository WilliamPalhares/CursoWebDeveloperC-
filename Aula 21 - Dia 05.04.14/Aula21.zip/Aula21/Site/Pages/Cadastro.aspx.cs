﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL.Model;
using DAL.Persistence;

namespace Site.Pages
{
    public partial class Cadastro : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if( ! IsPostBack ) //página executando pela 1º vez
            {
                CarregarDados();
            }
        }

        protected void btnCadastro_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente c = new Cliente();

                c.Nome  = txtNome.Text;  //campo nome
                c.Email = txtEmail.Text; //campo email
                c.DataCadastro = DateTime.Now; //data do sistema

                ClienteDal d = new ClienteDal();
                d.Salvar(c);

                txtNome.Text  = string.Empty; //vazio
                txtEmail.Text = string.Empty; //vazio

                lblMensagem.Text = "Cliente " + c.Nome + ", cadastrado com sucesso.";
                CarregarDados();
            }
            catch(Exception ex)
            {
                lblMensagem.Text = ex.Message;
            }
        }

        private void CarregarDados()
        {
            try
            {
                ClienteDal d = new ClienteDal();

                gridClientes.DataSource = d.ListarTodos(); //preenche o grid
                gridClientes.DataBind(); //exibir
            }
            catch(Exception e)
            {
                lblMensagem.Text = e.Message; //mensagem de erro
            }
        }

    }
}