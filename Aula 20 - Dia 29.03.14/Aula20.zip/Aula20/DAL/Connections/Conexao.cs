﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NHibernate;
using NHibernate.Cfg;

namespace DAL.Connections
{
    public class Conexao
    {
        //Para que o Hibernate possa gerar conexões com uma base de dados é necessário que criemos
        //um componente chamado ISessioNFactory (Fábrica de Conexões) -> gerador de conexões
        public ISessionFactory Factory()
        {
            try
            {
                //Para conectar o hibernate em uma base de dados são necessários algumas configurações...
                Configuration Cfg = new Configuration(); //Classe para configuração do NHibernate

                Cfg.SetProperty(NHibernate.Cfg.Environment.ConnectionProvider, "NHibernate.Connection.DriverConnectionProvider");
                Cfg.SetProperty(NHibernate.Cfg.Environment.Dialect, "NHibernate.Dialect.MsSql2000Dialect");
                Cfg.SetProperty(NHibernate.Cfg.Environment.ConnectionDriver, "NHibernate.Driver.SqlClientDriver");
                Cfg.SetProperty(NHibernate.Cfg.Environment.ConnectionString, @"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Note-HP\Desktop\Aula_29.03.14\Aula20\Site\App_Data\Banco.mdf;Integrated Security=True");

                //Nome do Projeto
                Cfg.AddAssembly("DAL");

                //Gerar e retornar a fábrica de conexões
                return Cfg.BuildSessionFactory();
            }
            catch(Exception e)
            {
                throw new Exception("Erro ao gerar fábrica de conexões: " + e.Message);
            }
        }

    }
}
