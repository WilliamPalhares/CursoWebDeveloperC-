﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NHibernate;
using DAL.Model;
using DAL.Connections;

namespace DAL.Persistence
{
    public class ClienteDal
    {
        //Atributos (API do Nhibernate)
        private ISession Session; //Capturar a Conexão com o banco de dados
        private ITransaction Transaction; //Executar transações na base (commit, rollback)
        private IQuery Query; //Executar consultas (linguagem HQL -> Hibernate Query Language)

        //Método para gravar Cliente e Endereco
        public void Salvar(Cliente c, Endereco e)
        {
            try
            {
                Conexao Con = new Conexao(); //Instanciando a Classe de Conexão
                Session = Con.Factory().OpenSession(); //abrindo conexão através da fábrica

                Transaction = Session.BeginTransaction(); //iniciando uma transação
                Session.Save(c); //insert
                Session.Save(e); //insert
                Transaction.Commit(); //executar
            }
            catch(Exception ex)
            {
                Transaction.Rollback(); //desfazer
                throw new Exception("Erro ao salvar cliente: " + ex.Message);
            }
            finally
            {
                Session.Close(); //fechar a conexão
            }
        }
    }
}
