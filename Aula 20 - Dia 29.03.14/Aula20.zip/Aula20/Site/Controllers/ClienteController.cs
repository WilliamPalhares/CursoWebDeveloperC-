﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Site.Models; //camada de modelo
using DAL.Model;
using DAL.Persistence;

namespace Site.Controllers
{
    public class ClienteController : Controller
    {
        //Método gerador de rota => Abrir página => /Cliente/Cadastro
        public ActionResult Cadastro() //Nome da página
        {
            return View();
        }

        //Método para resgatar o envio de dados realizado pelo formulário
        [HttpPost] //indicando que o método é chamado por formulário com requisição POST
        public ActionResult CadastrarCliente(ClienteModel Model) //classe de modelo
        {
            try
            {
                Cliente c = new Cliente(); //entidade mapeada
                c.Nome       = Model.Nome;
                c.Sexo       = Model.Sexo;
                c.DataCadastro = DateTime.Now;

                Endereco e = new Endereco(); //entidade mapeada
                e.Logradouro = Model.Logradouro;
                e.Cidade     = Model.Cidade;
                e.Estado     = Model.Estado;
                e.Tipo       = Model.Tipo;

                //Relacionar
                e.Cliente = c; //faz com que o hibernate grave relacionado (foreign key)

                ClienteDal d = new ClienteDal();
                d.Salvar(c, e); //gravação

                ViewBag.Mensagem = "Cliente cadastrado com sucesso.";
                ModelState.Clear(); //limpa o conteudo dos campos do formulário
            }
            catch(Exception ex)
            {
                ViewBag.Mensagem = ex.Message;
            }

            //redirecionamento
            return View("Cadastro"); //nome da página
        }
    }
}
