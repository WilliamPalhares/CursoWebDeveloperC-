﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations; //mapeamento

namespace Site.Models
{
    public class ClienteModel
    {        
        [Display(Name = "Nome do Cliente:")]
        public string Nome { get; set; }

        [Display(Name = "Sexo:")]
        public char Sexo { get; set; }

        [Display(Name = "Logradouro:")]
        public string Logradouro { get; set; }

        [Display(Name = "Cidade:")]
        public string Cidade { get; set; }

        [Display(Name = "Estado:")]
        public string Estado { get; set; }

        [Display(Name = "Tipo do Endereço:")]
        public string Tipo { get; set; }
    }
}