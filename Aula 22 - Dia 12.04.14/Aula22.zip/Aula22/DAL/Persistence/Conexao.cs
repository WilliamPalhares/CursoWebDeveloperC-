﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient; //System.Data.SqlClient
using System.Configuration;

namespace DAL.Persistence
{
    public class Conexao
    {
        protected MySqlConnection Con;
        protected MySqlCommand Cmd;
        protected MySqlDataReader Dr;

        protected void AbrirConexao()
        {
            Con = new MySqlConnection(ConfigurationManager.ConnectionStrings["mysql"].ConnectionString);
            Con.Open();
        }

        protected void FecharConexao()
        {
            Con.Close();
        }
    }
}
