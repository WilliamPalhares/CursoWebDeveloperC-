﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using DAL.Model;

namespace DAL.Persistence
{
    public class MensagemDal : Conexao
    {
        //Método para gravar o registro da mensagem na tabela do MySql
        public void Salvar(Mensagem m)
        {
            try
            {
                AbrirConexao();
                Cmd = new MySqlCommand("insert into mensagem values(null, @destinatario, @assunto, @mensagem, now())", Con);
                Cmd.Parameters.AddWithValue("@destinatario", m.Destinatario);
                Cmd.Parameters.AddWithValue("@assunto", m.Assunto);
                Cmd.Parameters.AddWithValue("@mensagem", m.Texto);
                Cmd.ExecuteNonQuery(); //executar
            }
            catch(Exception e)
            {
                throw new Exception("Erro ao salvar mensagem: " + e.Message);
            }
            finally
            {
                FecharConexao();
            }
        }
    }
}
