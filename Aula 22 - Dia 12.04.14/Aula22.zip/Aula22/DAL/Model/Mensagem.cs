﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL.Model
{
    public class Mensagem
    {
        public int IdMensagem { get; set; }
        public string Destinatario { get; set; }
        public string Assunto { get; set; }
        public string Texto { get; set; }
        public DateTime DataEnvio { get; set; }
    }
}
