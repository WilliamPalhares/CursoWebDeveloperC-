﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL.Model;
using DAL.Persistence;
using System.Net;
using System.Net.Mail;

namespace Site.Pages
{
    public partial class Contato : System.Web.UI.Page
    {
        //Atributos (encapsulamento implicito)
        public string Conta { get; set; }   //recebera um valor vindo de xml
        public string Senha { get; set; }   //recebera um valor vindo de xml
        public string Smtp { get; set; }    //recebera um valor vindo de xml
        public int Porta { get; set; }      //recebera um valor vindo de xml


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void EnviarMensagem(object sender, EventArgs e)
        {
            try
            {
                Mensagem m = new Mensagem();

                m.Destinatario = txtDestinatario.Text;
                m.Assunto = txtAssunto.Text;
                m.Texto = txtMensagem.Text;

                MensagemDal d = new MensagemDal();
                d.Salvar(m);

                //Envio do email
                MailMessage msg = new MailMessage(Conta, m.Destinatario); // de -> para
                msg.Subject = m.Assunto;
                msg.Body = m.Texto;

                SmtpClient s = new SmtpClient(Smtp, Porta);
                s.EnableSsl = true; //envio de email seguro
                s.Credentials = new NetworkCredential(Conta, Senha);
                s.Send(msg); //envio do email

                lblMensagem.Text = "Mensagem " + m.Assunto + ", enviada com sucesso.";
            }
            catch(Exception ex)
            {
                lblMensagem.Text = ex.Message;
            }
        }
    }
}